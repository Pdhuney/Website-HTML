var nameNode = document.getElementById("name")
nameNode.addEventListener("click", function(){
    alert("Klik op de header voor meer informatie")
});

var nameNode = document.getElementById("name1")
nameNode.addEventListener("click", function(){
    alert("Klik op de header voor meer informatie")
});

var nameNode = document.getElementById("name2")
nameNode.addEventListener("click", function(){
    alert("Klik op de header voor meer informatie")
});